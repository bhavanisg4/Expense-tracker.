SMART EXPENSE TRACKER — QUICK START

1. Extract the ZIP file.
2. Open the Smart_Expense_Tracker folder in Visual Studio Code.
3. Open index.html in Google Chrome or Microsoft Edge.
   Recommended: install the VS Code "Live Server" extension, right-click index.html,
   then choose "Open with Live Server".
4. Create a demo account using your name, email and a test password.
5. Add a transaction manually or click "Use microphone".

FEATURES
- Income and expense records with amount, date, category, payment mode and note
- Automatic income, expense and balance calculations
- Monthly overall and category budgets with 80% / 100% warnings
- Savings goals and contributions
- Recurring bill reminders
- Category and monthly charts
- Search and filters
- CSV report download
- Voice input through the browser Web Speech API

IMPORTANT LIMITATIONS
- This is a front-end mini-project prototype. Data is stored in the browser's localStorage.
- The sign-in is a demonstration only; it is NOT secure production authentication.
  Do not enter a real password or sensitive financial details.
- For a real multi-user deployment, add a backend (for example Node.js/Express),
  password hashing, HTTPS, server-side authorization and a database such as MySQL.
- Voice recognition depends on browser support, microphone permission and internet/browser
  speech services. Chrome or Edge is recommended. Voice input fills the form; review it
  before saving.
- Chart.js and Google Fonts load from the internet.

TECHNOLOGIES
HTML5, CSS3, JavaScript, localStorage, Chart.js, Web Speech API.
